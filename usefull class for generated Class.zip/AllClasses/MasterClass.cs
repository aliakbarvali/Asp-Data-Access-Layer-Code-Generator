﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for MasterClass
/// </summary>
public interface MasterClass
{ 
    //ReturnedData Update2_PropertyValue_OneByPK(object Article_ID_value, string ColumnName, object value);
    //ReturnedData Update5_PropertyValue_PropertyValue_ByPK(object Article_ID_value, string ColumnName1, object value1, string ColumnName2, object value2);


}