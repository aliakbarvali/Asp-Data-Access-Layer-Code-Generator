﻿using System;
using System.Collections.Generic; 
using System.Web;
public static class MessageData
{
    public static string Success = "عملیات با موفقیت انجام شد";
    public static string Success_Select = "انتخاب با موفقیت انجام شد";
    public static string Success_Update = "بروزرسانی با موفقیت انجام شد";
    public static string Success_Delete = "حذف با موفقیت انجام شد";
    public static string Success_Insert = "درج با موفقیت انجام شد";


    public static string Faile = "عملیات انجام نشد";
    public static string Faile_Select = "انتخاب انجام نشد";
    public static string Faile_Update = "بروزرسانی انجام نشد";
    public static string Faile_Delete = "حذف انجام نشد";
    public static string Faile_Insert = "درج انجام نشد";


    public static string Error = "عملیات با خطا مواجه شد";
    public static string Error_Select = "انتخاب با خطا مواجه شد";
    public static string Error_Update = "بروزرسانی با خطا مواجه شد";
    public static string Error_Delete = "حذف با خطا مواجه شد";
    public static string Error_Insert = "درج با خطا مواجه شد";


    public static string Error_intType = "نوع داده باید عدد صحیح باشد";
    public static string Error_floatType = "نوع داده باید عدد باشد";
    public static string Error_Range = "داده باید در محدوده مناسب باشد";
    public static string Error_len = "طول داده نامناسب است";


    public static string notFound = "داده ای یافت نشد";
    public static string notFound_Select = "داده ای برای انتخاب یافت نشد";
    public static string notFound_Update = "داده ای برای بروزرسانی یافت نشد";
    public static string notFound_Delete = "داده ای برای حذف یافت نشد";
    public static string EditLOCK_ON = "امکان ویرایش وجود ندارد";

    public static string isRequired(string name)
    {
        if(name != null)
            return string.Format("فیلد {0} نمی تواند خالی باشد", name);
        else
            return string.Format("فیلد نمی تواند خالی باشد");
    }  

    public static string T_int(string name)
    {
        if(name != null)
       return string.Format(  "نوع داده {0} باید از نوع صحیح باشد" , name);
        else
            return string.Format("نوع داده باید از نوع صحیح باشد");
    }
    public static string T_bool(string name )
    {
        return string.Format("نوع داده {0} باید از نوع بولین باشد", name);
    }
    public static string T_char(string name )
    {
        return string.Format("نوع داده {0} باید از نوع کاراکتری باشد", name);
    }
    public static string T_float(string name )
    {
        return string.Format("نوع داده {0} باید از نوع اعشاری باشد", name);
    }
    public static string T_double(string name )
    {
        return string.Format("نوع داده {0} باید از نوع اعشاری باشد", name);
    }
    public static string T_Int64(string name )
    {
        return string.Format("نوع داده {0} باید از نوع صحیح باشد", name);
    }
    public static string T_DateTime(string name )
    {
        return string.Format("نوع داده {0} باید از نوع تاریخ میلادی باشد", name);
    }
    public static string T_String(string name )
    {
        return string.Format("نوع داده {0} باید از نوع رشته باشد", name);
    } 

    public static string L_String(string len ,string name  ,  bool isFixedLen )
    {
        if(!isFixedLen)
        return string.Format("طول داده {0} باید کمتر از {1} باشد.", name , len);
        else
            return string.Format("طول داده {0} باید {1} باشد.", name, len);
    }
    public static string L_ForienKey(string name)
    {
        return string.Format("انتخاب نوع داده {0} الزامی است", name);
    } 
    public static string L_ForienKey(string len, string name, bool isFixedLen)
    {
        if (!isFixedLen)
            return string.Format("طول داده {0} باید کمتر از {1} باشد.", name, len);
        else
            return string.Format("طول داده {0} باید {1} باشد.", name, len);
    } 
}
public class ReturnedData
{
    public bool IsSuccessfull { get; set; }
    public int ReturnedValue_int { get; set; }
    public int Insert_ScopeIdentity { get; set; }
    public string ReturnedValue_string { get; set; }
    public object ReturnedValue_object { get; set; }
    public string Message { get; set; }
    public ReturnedData()
    {

    }
	
    public  static  ReturnedData DenyAccess()
    {
        ReturnedData d = new ReturnedData();
        d.Insert_ScopeIdentity = -1;
        d.IsSuccessfull = false;
        d.Message = "دسترسی محدود می باشد";
        d.ReturnedValue_string = "";
        return d;
    }
}

public class MyException : Exception
{
    public MyException()
        : base()
    {

    }

    public MyException(String message)
        : base(message)
    {
    }
    public MyException(String message, Exception innerException)
        : base(message, innerException)
    {
    }
}

public class MyExceptionType : MyException
{
    public MyExceptionType()
        : base()
    {

    }
    public MyExceptionType(String message)
        : base(message)
    {
    } 
}

public class MyExceptionLen : MyException
{
    public MyExceptionLen()
        : base()
    {

    }
    public MyExceptionLen(String message)
        : base(message)
    {
    }
}

public class MyExceptionRequired : MyException
{
    public MyExceptionRequired()
        : base()
    {

    }
    public MyExceptionRequired(String message)
        : base(message)
    {
    }
}