﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.IO;

    public static class Data
    {
        public static string connectionString = ConfigurationSettings.AppSettings["ConnectionString"];
    }
    public class Transaction
    {
        private SqlConnection connection;
        private SqlTransaction sqltransaction;
        private List<SqlCommand> Command = new List<SqlCommand>();
        public SqlTransaction sqlTransaction
        {
            get { return sqltransaction; }
            set { sqltransaction = value; }
        }
        private string transactionName;

        
        public Transaction(string transaction_Name)
        { 
            transactionName = transaction_Name;
        }
        public void AddCommand(SqlCommand command)
        {
            Command.Add(command);
        }
        public string ExecuteTransaction()
        {
            using (connection = new SqlConnection(Data.connectionString))
            {
                connection.Open();

                sqltransaction = connection.BeginTransaction(transactionName);
                try
                {
                    foreach (SqlCommand com in Command)
                    {
                        com.Connection = connection;
                        com.Transaction = sqltransaction;
                        com.ExecuteNonQuery();

                    }
                    sqltransaction.Commit();
                    return " رکورد در پایگاه داده ثبت گردید.";
                }
                catch (Exception ex)
                {
                    string s = "";
                    s = string.Format("نوع استثنای کامیت: {0} {1}", ex.GetType(), Environment.NewLine);
                    s += string.Format("پیام: {0}", ex.Message);
                    try
                    {
                        sqltransaction.Rollback();
                    }
                    catch (Exception ex2)
                    {
                        s = string.Format("نوع استثنای عقبگرد: {0}  {1} ", ex2.GetType(), Environment.NewLine);
                        s += string.Format("  پیام: {0}", ex2.Message);
                        return s;
                    }
                    return s;
                }

            }
        }
        public void StartTransaction()
        {
            connection.Open();
            sqlTransaction = connection.BeginTransaction(transactionName);
        }
        public string CommitTransaction()
        {
            try
            {
                sqlTransaction.Commit();
                
                connection.Close();
            }
            catch(Exception e)
            {

                try
                {
                    sqlTransaction.Rollback();
                }
                catch (Exception ex2)
                {
                    return "false Rollback";
                }
                return "false CommitTransaction";
            }
            return "true";
        }
    }

