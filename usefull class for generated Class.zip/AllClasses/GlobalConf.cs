﻿using System;
using System.Collections.Generic;
using System.Linq; 
using System.Text;
using System.Web.Mvc;
using System.Security.Principal;


class GlobalConf
{
    public bool isAdmin()
    {
        return   true;
    }
}


  public  enum AccessType
    {
        Admin = 0,
        User_OnlyVisible = 1, 
        IsEditable_RecordLock = 2,
        IsAccesibel_UserType = 3
    }